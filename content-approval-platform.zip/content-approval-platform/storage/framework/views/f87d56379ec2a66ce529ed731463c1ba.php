<?php $__env->startSection('content'); ?>
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="fa fa-list">
                        </i>
                    </div>
                    <div>Category Details
                        <div class="page-title-subheading">Manage categories from here...
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="container">
                
                <a class="btn btn-success btn-sm" href="<?php echo e(route('categories.create')); ?>">
                    <i class="fa fa-plus"></i> Add Category</a>
                <hr>

                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($category->id ?? ''); ?></th>
                                <td><?php echo e($category->name ?? ''); ?></td>
                                <td>
                                    <a href="<?php echo e(route('categories.edit', $category->id)); ?>"
                                        class="btn btn-sm btn-primary"><i class="fa fa-edit"></i> Edit</a>
                                    <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="POST"
                                        style="display:inline-block"
                                        onsubmit="return confirm('Are you sure you want to delete this category?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\content-approval-platform\resources\views/categories/index.blade.php ENDPATH**/ ?>