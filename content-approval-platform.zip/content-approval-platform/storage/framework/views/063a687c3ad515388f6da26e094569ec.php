<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="mb-4">All Posts</h1>
    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary mb-3">Create New Post</a>

    <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
            <thead class="table-dark">
                <tr>
                    <th></th>
                    <th>SL.</th>
                    <th>Title</th>
                    <th>Content</th>
                    <th>Categories</th>
                    <th>Tags</th>
                    <th>Author</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td></td>
                    <td><?php echo e($post->id ?? ''); ?></td>
                    <td><?php echo e($post->title ?? ''); ?></td>
                    <td><?php echo e($post->content ?? ''); ?></td>

                    <td>
                        <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-secondary text-white"><?php echo e($category->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>

                    <td>
                        <span class="badge bg-info text-dark"><?php echo e($post->tags); ?></span>
                    </td>

                    <td><?php echo e($post->user->name); ?></td>

                    <?php if($post->status === 'pending'): ?>
                    <td>Pending</td>
                    <?php elseif($post->status === 'approved'): ?>
                    <td>Approved</td>
                    <?php elseif($post->status === 'rejected'): ?>
                    <td>Rejected</td>
                    <?php else: ?>
                    <td>Archived</td>
                    <?php endif; ?>

                    <td>
                        <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this post?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">No posts found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.userLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\content-approval-platform\resources\views/posts/index.blade.php ENDPATH**/ ?>