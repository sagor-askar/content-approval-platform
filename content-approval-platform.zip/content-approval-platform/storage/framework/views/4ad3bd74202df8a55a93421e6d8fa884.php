<?php $__env->startSection('content'); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="fa fa-list">
                    </i>
                </div>
                <div>Content Approval
                    <div class="page-title-subheading">Approve Stories From Here
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="container">
            <h5>New Content</h5>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th></th>
                        <th>SL.</th>
                        <th>Title</th>
                        <th>Content</th>
                        <th>Categories</th>
                        <th>Tags</th>
                        <th>Author</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $allContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($post->id ?? ''); ?></td>
                        <td><?php echo e($post->title ?? ''); ?></td>
                        <td><?php echo e($post->content ?? ''); ?></td>

                        <td>
                            <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-secondary text-white"><?php echo e($category->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>

                        <td>
                            <span class="badge bg-info text-dark"><?php echo e($post->tags); ?></span>
                        </td>

                        <td><?php echo e($post->user->name); ?></td>

                        <?php if($post->status === 'pending'): ?>
                        <td>Pending</td>
                        <?php elseif($post->status === 'approved'): ?>
                        <td>Approved</td>
                        <?php elseif($post->status === 'rejected'): ?>
                        <td>Rejected</td>
                        <?php else: ?>
                        <td>Archived</td>
                        <?php endif; ?>

                        <td>
                            <form action="<?php echo e(route('posts.updateStatus', $post)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <button type="submit" name="status" value="approved" class="btn btn-sm btn-success" onclick="return confirm('Approve this post?')">Approve</button>

                                <button type="submit" name="status" value="rejected" class="btn btn-sm btn-warning" onclick="return confirm('Reject this post?')">Reject</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">No posts found.</td>
                    </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>

        <hr>

        <div class="container">
            <h5>Approved Content</h5>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th></th>
                        <th>SL.</th>
                        <th>Title</th>
                        <th>Content</th>
                        <th>Categories</th>
                        <th>Tags</th>
                        <th>Author</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $approvedContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($post->id ?? ''); ?></td>
                        <td><?php echo e($post->title ?? ''); ?></td>
                        <td><?php echo e($post->content ?? ''); ?></td>

                        <td>
                            <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-secondary text-white"><?php echo e($category->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>

                        <td>
                            <span class="badge bg-info text-dark"><?php echo e($post->tags); ?></span>
                        </td>

                        <td><?php echo e($post->user->name); ?></td>

                        <?php if($post->status === 'pending'): ?>
                        <td>Pending</td>
                        <?php elseif($post->status === 'approved'): ?>
                        <td>Approved</td>
                        <?php elseif($post->status === 'rejected'): ?>
                        <td>Rejected</td>
                        <?php else: ?>
                        <td>Archived</td>
                        <?php endif; ?>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">No posts found.</td>
                    </tr>
                    <?php endif; ?>

                </tbody>
            </table>

        </div>

        <hr>

        <div class="container">
            <h5>Archived Content</h5>
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th></th>
                        <th>SL.</th>
                        <th>Title</th>
                        <th>Content</th>
                        <th>Categories</th>
                        <th>Tags</th>
                        <th>Author</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $archivedContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($post->id ?? ''); ?></td>
                        <td><?php echo e($post->title ?? ''); ?></td>
                        <td><?php echo e($post->content ?? ''); ?></td>

                        <td>
                            <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-secondary text-white"><?php echo e($category->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>

                        <td>
                            <span class="badge bg-info text-dark"><?php echo e($post->tags); ?></span>
                        </td>

                        <td><?php echo e($post->user->name); ?></td>

                        <?php if($post->status === 'pending'): ?>
                        <td>Pending</td>
                        <?php elseif($post->status === 'approved'): ?>
                        <td>Approved</td>
                        <?php elseif($post->status === 'rejected'): ?>
                        <td>Rejected</td>
                        <?php else: ?>
                        <td>Archived</td>
                        <?php endif; ?>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">No posts found.</td>
                    </tr>
                    <?php endif; ?>

                </tbody>
            </table>

        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\content-approval-platform\resources\views/approval/index.blade.php ENDPATH**/ ?>